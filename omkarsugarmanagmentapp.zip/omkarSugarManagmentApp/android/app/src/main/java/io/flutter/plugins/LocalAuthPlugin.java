package io.flutter.plugins;

import android.app.Activity;

public class LocalAuthPlugin extends Activity {
    // Ensure the class is public
    public LocalAuthPlugin() {
        // Provide an empty public constructor
    }

    // Your class implementation here
}
package com.example.omkarsugarmanagmentapp;


import io.flutter.embedding.android.FlutterFragmentActivity;


public class MainActivity extends FlutterFragmentActivity {
}

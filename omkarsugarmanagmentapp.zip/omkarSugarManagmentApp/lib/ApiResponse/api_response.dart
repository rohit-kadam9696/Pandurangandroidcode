
class ApiResponse{

  static String  determineBaseUrl(String sugarFactoryId) {
    String hostname = "";
    String port = "";
    switch (sugarFactoryId) {
      case '1':
        hostname = "192.168.0.127"; // Change hostname for factory 1
        port = "8080"; // Change port number for factory 1
        break;
      case '2':
        hostname = "192.168.0.127"; // Change hostname for factory 2
        port = "8080"; // Change port number for factory 2
        break;
      case '3':
        hostname = "192.168.0.127"; // Change hostname for factory 3
        port = "8080"; // Change port number for factory 3
        break;
      case '4':
        hostname = "192.168.0.127"; // Change hostname for factory 4
        port = "8080"; // Change port number for factory 4
        break;
      case '5':
        hostname = "192.168.0.127"; // Change hostname for factory 5
        port = "8080"; // Change port number for factory 5
        break;
      case '6':
        hostname = "192.168.0.127"; // Change hostname for factory 5
        port = "8080"; // Change port number for factory 5
        break;
      default:
        //hostname = "192.168.0.120";
      // Default hostname
        hostname = "192.168.0.127";
        port = "8080"; // Default port number
        break;
    }

    return "http://$hostname:$port/FlutterOnkarSugar";
  }
}
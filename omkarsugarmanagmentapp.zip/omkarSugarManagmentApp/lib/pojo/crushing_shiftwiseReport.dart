class ShiftCrushingResponse {
  final int nsugTypeId;
  final int nlocationId;
  final Map<String, ShiftCrushingData> shiftWiseCrushingBeanMap;
  final bool success;
  final bool update;

  ShiftCrushingResponse({
    required this.nsugTypeId,
    required this.nlocationId,
    required this.shiftWiseCrushingBeanMap,
    required this.success,
    required this.update,
  });


  factory ShiftCrushingResponse.fromJson(Map<String, dynamic> json) {
    var shiftWiseCrushingBeanMap = <String, ShiftCrushingData>{};

    // Check if 'shiftWiseCrushingBeanMap' key exists in the JSON
    if (json.containsKey('shiftWiseCrushingBeanMap')) {
      // Check if the value is not null
      if (json['shiftWiseCrushingBeanMap'] != null) {
        // Iterate over the entries and parse ShiftCrushingData
        json['shiftWiseCrushingBeanMap'].forEach((key, value) {
          shiftWiseCrushingBeanMap[key] = ShiftCrushingData.fromJson(value);
        });

        return ShiftCrushingResponse(
          nsugTypeId: json['nsugTypeId'],
          nlocationId: json['nlocationId'],
          shiftWiseCrushingBeanMap: shiftWiseCrushingBeanMap,
          success: json['success'],
          update: json['update'],
        );
      }
    }


    throw FormatException("Invalid JSON structure for CrushingResponse");
  }


}

class ShiftCrushingData {
  final num shiftTodayCrushing;
  final num shiftYeastrdayCrushing;
  final String shiftNo;

  ShiftCrushingData({
    required this.shiftTodayCrushing,
    required this.shiftYeastrdayCrushing,
    required this.shiftNo,
  });

  factory ShiftCrushingData.fromJson(Map<String, dynamic> json) {
    return ShiftCrushingData(
      shiftTodayCrushing: json['shiftTodayCrushing'],
      shiftYeastrdayCrushing: json['shiftYeastrdayCrushing'],
      shiftNo: json['shiftNo'],
    );
  }
}

const appname = "ओंकार शुगर आणि डिस्टिलरी पावर प्रा.लि.";
const appversion = "Version 1.0.0";
const credits = "@Rohit Kadam";
const mobile="मोबाइल नंबर";
const mobileNohint="कृपया मोबाइल क्रमांक टाका.";
const password="Password";
const passwordHint="************";
const forgetPassword="लॉगइन";
const login="लॉग इन";
const signup="Sign Up";
const createNewAccount="or, create a new account";
const loginWith="Login in with";

const newPin="नवीन पिन";
const newPinhint="कृपया नवीन पिन टाका.";

const reenterNewPin="नवीन पिन पुन्हा टाका.";
const reenterNewPinhint="कृपया नवीन पिन पुन्हा टाका.";




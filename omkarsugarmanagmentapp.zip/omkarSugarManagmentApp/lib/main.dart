import 'package:flutter/material.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:get/get_navigation/src/routes/get_route.dart';
import 'package:omkarsugarmanagmentapp/GridView/sugargactory_gridview.dart';
import 'package:omkarsugarmanagmentapp/SharedPreference/shared_pref.dart';
import 'package:omkarsugarmanagmentapp/TabView/bottom_nav.dart';
import 'package:omkarsugarmanagmentapp/TabView/tab_1.dart';
import 'package:omkarsugarmanagmentapp/TabView/tab_2.dart';
import 'package:omkarsugarmanagmentapp/TabView/tab_3.dart';
import 'package:omkarsugarmanagmentapp/TabView/tab_4.dart';
import 'package:omkarsugarmanagmentapp/UI/change_pin_activity.dart';
import 'package:omkarsugarmanagmentapp/auth_screen/auth_controller.dart';
import 'package:omkarsugarmanagmentapp/auth_screen/login_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'UI/splash_screen.dart';
import 'consts/styles.dart';
import 'package:upgrader/upgrader.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Only call clearSavedSettings() during testing to reset internal values.
  await Upgrader.clearSavedSettings();
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  late Future<void> _checkLoginFuture=Future.value();
  bool _loggedIn = false;
  String ? pin;


  @override
  void initState() {
    super.initState();
    _checkLoginFuture = _checkLoggedInStatus();
  }
  Future<void> _checkLoggedInStatus() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? mobileNo = prefs.getString('mobileNo');
    String? pin = prefs.getString('loginPin');
    if (mobileNo != null && mobileNo.isNotEmpty) {
      setState(() {
        _loggedIn = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        useMaterial3: true,
      ),
      home: _loggedIn ? SplashScreen() : MyGridView(),
      getPages: [

        GetPage(name: '/home', page: () => MyGridView()),
        GetPage(name: '/auth', page: () => _loggedIn ?SplashScreen() : MyGridView()),
        GetPage(name: '/loginPin', page: () => ChangePinActivity()),
        GetPage(name: '/authenticate', page: () => SplashScreen()),
        GetPage(name: '/bottomNav', page: () => BottomNav()),
        GetPage(name: '/login', page: () => const LoginScreen()),
        GetPage(name: '/tab4', page: () => const Tab4()),
        GetPage(name: '/changePin', page: () {
        if (_loggedIn && (pin == null || pin!.isEmpty)) {
       return ChangePinActivity();
       }
        else {
        return AuthenticateController();
        }
    }),
      ],
    );
  }
}

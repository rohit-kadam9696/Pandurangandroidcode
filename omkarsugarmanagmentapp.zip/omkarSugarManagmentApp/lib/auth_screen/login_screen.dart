


import 'dart:convert';
import 'dart:developer';

import 'package:device_info/device_info.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';
import 'package:omkarsugarmanagmentapp/ApiResponse/api_response.dart';
import 'package:omkarsugarmanagmentapp/GridView/sugargactory_gridview.dart';
import 'package:omkarsugarmanagmentapp/SharedPreference/shared_pref.dart';
import 'package:omkarsugarmanagmentapp/UI/otp_activity.dart';
import 'package:omkarsugarmanagmentapp/widget_common/loadinganim.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:toastification/toastification.dart';

import '../ButtonClickAction/login_button_click.dart';
import '../Services/api_services.dart';
import '../consts/consts.dart';
import '../widget_common/applogo_widget.dart';
import '../widget_common/bg_widget.dart';
import '../widget_common/circular_progressbar.dart';
import '../widget_common/custom_textfield.dart';
import '../widget_common/progress_bar.dart';
import 'dart:convert' as convert;
import 'dart:io';

import 'dart:convert' as convert;
import 'dart:io';
import 'package:device_info/device_info.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:permission_handler/permission_handler.dart';

import 'package:http/http.dart' as http;
class LoginScreen extends StatefulWidget {
  final String? sugarFactoryId; // Add index parameter
  final int? index;

  const LoginScreen({super.key, this.sugarFactoryId, this.index});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {

  static String sugarFactoryId = '';
  static String _storedIdentifier = '';
  String _currentIdentifier = '';
  static String identifier = 'Identifier not available';
  bool isContainerVisible = false;
  @override
  void initState() {
    super.initState();
    _getDeviceInfo();
    _getStoredIdentifier();
    setState(() {
      sugarFactoryId = widget.sugarFactoryId ?? '';

      print("Login sugarfid: ${sugarFactoryId}");
    });
  }
  Future<void> _getDeviceInfo() async {
    DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();

    try {
      if (Platform.isAndroid) {
        // Request permission to access phone state
        var status = await Permission.phone.status;
        if (!status.isGranted) {
          await Permission.phone.request();
          status = await Permission.phone.status;
        }
        if (status.isGranted) {
          AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
          String imei = androidInfo.androidId ?? 'IMEI not available';
          setState(() {
            identifier = imei;
          });
        } else {
          print('Permission denied to access phone state');
        }
      } else if (Platform.isIOS) {
        // iOS code to retrieve identifierForVendor
      }
    } catch (e) {
      print('Error getting device info: $e');
    }
  }



  Future<void> _getStoredIdentifier() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      _storedIdentifier = prefs.getString('identifier') ?? '';
    });
  }

  Future<void> _updateIdentifier() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('identifier', _currentIdentifier);
    setState(() {
      _storedIdentifier = _currentIdentifier;
    });
  }
  DateTime? currentBackPressTime;
  Future<bool> _onWillPop() async {
    final now = DateTime.now();
    if (currentBackPressTime == null ||
        now.difference(currentBackPressTime!) > Duration(seconds: 1)) {
      currentBackPressTime = now;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Press back again to exit'),
        ),
      );
      return false;
    } else {
      SystemNavigator.pop();
      return true;
    }
  }




  static const Color green = Color(0xff31410c);
  @override
  Widget build(BuildContext context) {
    TextEditingController mobileno = TextEditingController();
    return Scaffold(
        resizeToAvoidBottomInset: false,
        body: Stack(children: [
          Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage(imgBackground),
                  fit: BoxFit.cover, // Ensure the background image covers the entire container
                ),
              ),
              child: SizedBox.expand()
          ),

          bgWidget(
            margin: EdgeInsets.only(top: 230,left: 20,right: 20,bottom: 60),
          //  padding: EdgeInsets.only(bottom: 40),
            padding: EdgeInsets.only(left: 10,right: 10),
            backgroundColor: green,
            child: SafeArea(
              child: Column(
                children: [
                  (context.screenWidth).widthBox,

                  Column(
                    children: [
                      Container(
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.white,

                              border: Border.all(color: Colors.green,width: 3)
                          ),
                          child: ClipOval(child: Lottie.asset('assets/animations/loginanim.json',width: 150,height: 150,)
                          )

                      ),
                      customTextfield(hint: mobileNohint,title: mobile,controller: mobileno),
                      10.heightBox,
                      Align(
                        alignment: Alignment.center,
                        child: Container(
                          //width: double.infinity,
                            padding: EdgeInsets.only(left: 25,right: 25),
                            color:green,
                            child: TextButton(
                                style: TextButton.styleFrom(
                                  backgroundColor: Colors.green,
                                  padding: EdgeInsets.symmetric(
                                    horizontal: 20,
                                    vertical: 5,
                                  ),
                                ),
                                onPressed: () async {

                                  String phoneno = mobileno.text;

                                  if (phoneno.isEmpty) {

                                    double height = 220.0;
                                    String mobileNoEmptyMsg = "कृपया मोबाइल क्रमांक टाका.";
                                    print("Please Enter Mobile Number");
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Container(
                                          padding: EdgeInsets.all(20),
                                          decoration: BoxDecoration(
                                            color: Colors.red,
                                            borderRadius: BorderRadius.circular(10), // Adjust the border radius
                                            border: Border.all(
                                              color: Colors.greenAccent,
                                              width: 2.0, // Adjust the border width
                                            ),
                                          ),
                                          child: Padding(
                                            padding: const EdgeInsets.only(left: 50),
                                            child: Text(
                                              "कृपया मोबाइल क्रमांक टाका.",
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 20,


                                              ),
                                            ),
                                          ),

                                        ),
                                        duration: Duration(seconds: 3),
                                        backgroundColor: Colors.transparent,
                                      ),
                                    );
                                  }
                                  else if (phoneno.length < 10) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Container(
                                          padding: EdgeInsets.all(16),
                                          decoration: BoxDecoration(
                                            color: Colors.red,
                                            borderRadius: BorderRadius.circular(
                                                10), // Adjust the border radius
                                            border: Border.all(
                                              color: Colors.greenAccent,
                                              width: 2.0, // Adjust the border width
                                            ),
                                          ),
                                          child: Padding(
                                            padding: const EdgeInsets.only(
                                                left: 40),
                                            child: Text(
                                              "फोन नंबर चुकीचा आहे.",
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 20,
                                              ),
                                            ),
                                          ),
                                        ),
                                        duration: Duration(seconds: 3),
                                        backgroundColor: Colors.transparent,
                                      ),
                                    );
                                  }
                                  else if (phoneno.length > 12) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Container(
                                          padding: EdgeInsets.all(16),
                                          decoration: BoxDecoration(
                                            color: Colors.red,
                                            borderRadius: BorderRadius.circular(
                                                10), // Adjust the border radius
                                            border: Border.all(
                                              color: Colors.greenAccent,
                                              width: 2.0, // Adjust the border width
                                            ),
                                          ),
                                          child: Padding(
                                            padding: const EdgeInsets.only(
                                                left: 30),
                                            child: Text(
                                              "कृपया योग्य मोबाइल क्रमांक टाका.",
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 20,
                                              ),
                                            ),
                                          ),
                                        ),
                                        duration: Duration(seconds: 3),
                                        backgroundColor: Colors.transparent,
                                      ),
                                    );

                                  }
                                  else{


                                    Future.delayed(Duration(seconds: 10), () {
                                      setState(() {
                                        isContainerVisible = !isContainerVisible; // Hide the container
                                      });
                                    });

                                    print("hiii hello");

                                    // Lottie.asset('assets/animations/loadinganim.json');
                                     String chitBoyId = "";
                                     String randomString = "";
                                    String versionId = await AppInfo.getVersionId();
                                     SharedPreferencesHelper.updateMobileNo(phoneno);





                                    print("identifier: ${identifier}");
                                   doLogin(phoneno, identifier, randomString, versionId, chitBoyId,sugarFactoryId);

                                    setState(() {
                                      isContainerVisible = !isContainerVisible; // Toggle the visibility
                                    });

                                    // Navigator.pushReplacement(
                                    //   context,
                                    //   MaterialPageRoute(builder: (context) => LoginScreen(sugarFactoryId: sugarFactoryId,index:widget.index,)),
                                    // );

                                    // Get.to(() => OtpActivity(
                                    //   imei: identifier,
                                    //   randomString: randomString,
                                    //   versionId: versionId,
                                    //   chitBoyId: chitBoyId,
                                    //   sugarFactoryId: sugarFactoryId,
                                    // ));
                                  }
                                },
                                child: Container(padding: EdgeInsets.only(left: 38),width: 200,height: 40,child: login.text.color(Colors.white).fontFamily(bold).size(24).make()))),
                      ),
                      5.heightBox,


                      SafeArea(
                        child: Visibility(
                          visible: isContainerVisible,
                          child: Container(

                            width: 200, // Adjust the width as needed
                            height: 200, // Adjust the height as needed
                            margin: EdgeInsets.only(left: 20, right: 40),
                            padding: EdgeInsets.only(bottom: 26), // Adjust padding as needed
                            decoration: BoxDecoration(
                              shape: BoxShape.circle, // Shape set to circular
                              color: green,
                            ),
                            child: ClipOval(
                              child: Lottie.asset(
                                'assets/animations/animm.json',
                                width: 500, // Adjust the width of the animation
                                height: 500,
                                // Adjust the height of the animation
                              ),
                            ),
                          ),
                        ),
                      )

                      //ourButton(color: redColor,title: login,textColor: whiteColor,onPress: (){}).box.width(context.screenWidth-50).make(),
                    ],
                  ).box.roundedFull.rounded.padding(EdgeInsets.only(left: 10,right: 10)).make(),


                ],),
            ),
          ),

        ],)


    );


  }

  Future<void> doLogin(String mobileno, String imei, String randomString, String versionId, String chitBoyId, String sugarFactoryId) async {
    if (mobileno.isNotEmpty) {
      String baseUrl = ApiResponse.determineBaseUrl(sugarFactoryId);
      print("baseurl os: ${baseUrl}");
      String uri = '$baseUrl/app_login';
      print("uri is: ${uri}");
      Map<String, dynamic> requestBody = {
        'action': "Login",
        'mobileno': mobileno,
        'imei': imei,
        'randomString': randomString,
        'versionId': versionId,
        'chitBoyId': chitBoyId,
        'sugarFactoryId': sugarFactoryId,
      };

      String json = jsonEncode(requestBody);
      try {
        var res = await http.post(
          Uri.parse(uri),
          body: json,
          headers: {'Content-Type': 'application/json'},
        );
        double customHeight = 220.0;
        if (res.statusCode == 200) {


          var jsondecode = jsonDecode(res.body);
          log("Login response: $jsondecode");
          if (jsondecode.containsKey("success") && jsondecode["success"] == true) {
            String chitBoyId = jsondecode["chitBoyId"];
            String randomString = jsondecode["uniquestring"];
            String mobileno = jsondecode["mobileno"];
            await SharedPreferencesHelper.storeValuesInSharedPref(chitBoyId, randomString, mobileno, imei, sugarFactoryId);
            SharedPreferencesHelper.updateSugarFactoryId(sugarFactoryId);
            String storedMobileNo = await SharedPreferencesHelper.getMobileNo();
            String oldPin = await SharedPreferencesHelper.getLoginPin();

            setState(() {
              storedMobileNo = storedMobileNo;
              oldPin = oldPin;
            });

            Get.to(() => OtpActivity(
              imei: imei,
              randomString: randomString,
              versionId: versionId,
              chitBoyId: chitBoyId,
              sugarFactoryId: sugarFactoryId,
            ));
            //Get.to(() => Page())
          } else {
            String servererrormsg = jsondecode['se']['msg'];
            Get.snackbar('Error', servererrormsg, snackPosition: SnackPosition.BOTTOM, duration: Duration(seconds: 3));
          }
        } else {
          print('Error: ${res.statusCode}');
        }
      } catch (e) {
        print('Error in HTTP request: $e');
      }
    } else {
      print("Please Fill All Details");
    }
  }

}

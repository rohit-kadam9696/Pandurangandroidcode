

import '../consts/consts.dart';

Widget applogoWidget(){
  return Image.asset(icAppLogo).box.white.size(80,80).padding(EdgeInsets.all(8)).rounded.make();
}
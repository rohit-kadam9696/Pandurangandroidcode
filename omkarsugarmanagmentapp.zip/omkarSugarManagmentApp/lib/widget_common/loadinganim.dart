class LoadingHelper {
  static bool isLoading = false;
}
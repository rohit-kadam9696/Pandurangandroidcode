import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:lottie/lottie.dart';
import 'package:omkarsugarmanagmentapp/auth_screen/login_screen.dart';
import 'package:omkarsugarmanagmentapp/consts/consts.dart';

class MyGridView extends StatefulWidget {
  final int? index;
  const MyGridView({Key? key, this.index}) : super(key: key);

  @override
  State<MyGridView> createState() => _MyGridViewState();
}

class _MyGridViewState extends State<MyGridView> {
  int currentIndex = 0;
  late String sugarFactoryId;
  double curveHeight = 70.0;
  @override
  void initState() {
    super.initState();
    currentIndex = widget.index ?? 0;
    sugarFactoryId = (currentIndex + 1).toString();
  }
  @override
  Widget build(BuildContext context) {

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Container(

        margin: EdgeInsets.only(top: 20),
        child: Scaffold(
          appBar: AppBar(
            shape:  MyShapeBorder(curveHeight),
            title: appname.text.color(Colors.white).size(21).bold.fontFamily(Vx.amberHex600).make(),
            backgroundColor: Colors.green,
            centerTitle: false,
            toolbarHeight: 50,
          ),
          body: Container(
            height: MediaQuery.of(context).size.height,
   
            color: Colors.green,
            child: Stack(
              children: [
                Positioned.fill(
                  child: Container(

                    color:  Colors.green,
                    // decoration: BoxDecoration(
                    //   image: DecorationImage(
                    //     image: AssetImage('assets/background_image.jpg'), // Replace with your background image
                    //     fit: BoxFit.cover,
                    //   ),
                    // ),
                  ),
                ),
                Container(

                color: Colors.green,
                  child: Center(
                    child: SizedBox(

                      height: MediaQuery.of(context).size.height * 1.5,
                      child: Lottie.asset(

                        'assets/animations/colorfill.json',
                          // Replace with your Lottie animation JSON file
                        fit: BoxFit.fill// Adjust height as needed

                      ),
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(top: 70),
                  padding: EdgeInsets.only(left: 10, right: 5, top: 30),
                  child: VStack([
                    GridView.count(
                      shrinkWrap: true,
                      crossAxisCount: 2,
                      children: List.generate(
                        6, // Number of images
                            (index) {
                          // Generate a container with image and text for each index
                          return GestureDetector(
                            onTap: (){
                              setState(() {
                                currentIndex = index;
                                sugarFactoryId = (currentIndex + 1).toString();
                              });

                              Get.to(() => LoginScreen(sugarFactoryId: sugarFactoryId, index: index,));
                            },
                            child: Column(
                              children: [
                                Center(
                                  child: Container(
                                    margin: EdgeInsets.only(top: 5, left: 10, right: 5),
                                    padding: EdgeInsets.all(10),
                                    decoration: BoxDecoration(
                                      border: Border.all(color: Colors.black, width: 2),
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                    child: Padding(
                                      padding: const EdgeInsets.all(4.0),
                                      child: Image.asset(
                                        'assets/images/logosplash.png',
                                        width: 130,
                                        height: 130,
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                ),
                                SizedBox(height: 5), // Add space between image and text
                                "Unit- ${index + 1}".text.size(18).color(Colors.brown).bold.make(), // Display unit number
                              ],
                            ),
                          );
                        },
                      ),
                    ).expand()
                  ]),
                ),
              ],
            ),
          ),

        ),
      ),

        );

  }
}
class MyShapeBorder extends ContinuousRectangleBorder {
  const MyShapeBorder(this.curveHeight);
  final double curveHeight;

  @override
  Path getOuterPath(Rect rect, {TextDirection? textDirection}) => Path()
    ..moveTo(0, rect.size.height)
    ..quadraticBezierTo(
      rect.size.width / 2,
      rect.size.height + curveHeight * 2,
      rect.size.width,
      rect.size.height,
    )
    ..lineTo(rect.size.width, 0)
    ..lineTo(0, 0)
    ..close();
}


import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';
import 'package:omkarsugarmanagmentapp/SharedPreference/preference_helper.dart';
import 'package:omkarsugarmanagmentapp/SharedPreference/shared_pref.dart';
import 'package:omkarsugarmanagmentapp/TabView/bottom_nav.dart';
import 'package:omkarsugarmanagmentapp/auth_screen/auth_controller.dart';

import 'package:omkarsugarmanagmentapp/constant/snackbar_helper.dart';
import 'package:omkarsugarmanagmentapp/consts/consts.dart';
import 'package:omkarsugarmanagmentapp/widget_common/bg_widget.dart';
import 'package:omkarsugarmanagmentapp/widget_common/custom_textfield.dart';

class ChangePinActivity extends StatefulWidget {
   ChangePinActivity({super.key});

  @override
  State<ChangePinActivity> createState() => _ChangePinActivityState();
}

class _ChangePinActivityState extends State<ChangePinActivity> {
  TextEditingController newpinController=TextEditingController();
  TextEditingController reenternewpinController=TextEditingController();
  TextEditingController oldpinController=TextEditingController();

  late final String imei;
  late final String randomString;
  late final String versionId;
  late final String chitBoyId;

  //-_ChangePinActivityState( this.imei, this.randomString, this.versionId, this.chitBoyId);
  _ChangePinActivityState();
  void initState() {
    super.initState();
    //
    // PreferencesHelper.getOldPinFromSharedPreferences().then((oldPin) {
    //   oldpinController.text = oldPin;
    // });
  }


  DateTime? currentBackPressTime;
  Future<bool> _onWillPop() async {
    final now = DateTime.now();
    if (currentBackPressTime == null ||
        now.difference(currentBackPressTime!) > Duration(seconds: 1)) {
      currentBackPressTime = now;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Press back again to exit'),
        ),
      );
      return false;
    } else {
      SystemNavigator.pop();
      return true;
    }
  }
  @override
  void dispose(){
    super.dispose();
  }
  static const Color green = Color(0xff31410c);
  @override
  Widget build(BuildContext context) {
    return Scaffold(

        resizeToAvoidBottomInset: false,
        body: Stack(children: [
          Container(

              decoration: BoxDecoration(

                image: DecorationImage(
                  image: AssetImage(imgBackground),
                  fit: BoxFit.cover, // Ensure the background image covers the entire container
                ),
                // borderRadius: BorderRadius.circular(20),
                // border: Border.all(
                //   color: Colors.black,
                //   width: 2,
                // ),
              ),
              child: SizedBox.expand()
          ),

          bgWidget(
            margin: EdgeInsets.only(top: 260,left: 40,right: 40,bottom: 30),
            padding: EdgeInsets.only(bottom: 35 ),
            backgroundColor: green,
            width: 450,
            height: 440,
            child: SafeArea(
              child: Column(
                children: [
                  (context.screenWidth).widthBox,
                  Column(
                    children: [
                      Container(
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.white,

                              border: Border.all(color: Colors.green,width: 3)
                          ),
                          child: ClipOval(child: Lottie.asset('assets/animations/newPin.json',width: 150,height: 150,)
                          )

                      ),
                      10.heightBox,
                      changePin(hint: newPinhint, controller: newpinController),
                      1.heightBox,
                      changePin(hint: reenterNewPinhint, controller: reenternewpinController),
                      2.heightBox,
                      Align(
                        alignment: Alignment.center,
                        child: Container(
                          //width: double.infinity,
                            padding: EdgeInsets.only(left: 25,right: 25),
                            color:green,
                            child: TextButton(
                                style: TextButton.styleFrom(
                                  backgroundColor: Colors.green,
                                  padding: EdgeInsets.symmetric(
                                    horizontal: 20,
                                    vertical: 5,
                                  ),
                                ),
                                onPressed: () async {

                                    String newPin = newpinController.text.trim();
                                    String reenterPin = reenternewpinController.text.trim();

                                    if (newPin.isEmpty || reenterPin.isEmpty) {
                                      String msg = "कृपया आपला नवीन पिन टाका.";
                                      if (newPin.isEmpty) {
                                        SnackbarHelper.showSnackBar2(
                                          context,
                                          msg: msg,
                                          height: 220.0,
                                        );
                                      } else if (reenterPin.isEmpty) {
                                        msg = "कृपया आपला नवीन पिन पुन्हा टाका.";
                                        SnackbarHelper.showSnackBar2(
                                          context,
                                          msg: msg,
                                          height: 220.0,
                                        );
                                      }
                                      return; // Exit onPressed function if any field is empty
                                    }
                                    if (newPin != reenterPin) {
                                      String msg = "कृपया दोन्ही पिन सारखेच टाका.";
                                      SnackbarHelper.showSnackBar2(
                                        context,
                                        msg: msg,
                                        height: 220.0,
                                      );
                                      return; // Exit onPressed function if newPin and reenterPin do not match
                                    }
                                    String successMsg = "आपला पिन सफलतापूर्वक जतन केला गेला आहे.";
                                    SnackbarHelper.showSnackbar(
                                      context,
                                      msg: successMsg,
                                      height: 220.0,
                                    );
                                    performSetPin();
                                    try {
                                      Get.offAll(() => BottomNav());
                                    } catch (e, s) {
                                      print(s);
                                    }
                                  },


                                child: Container(padding: EdgeInsets.only(left: 38),width: 180,height: 40,child: login.text.color(Colors.white).fontFamily(bold).size(24).make()))),
                      ),
                      5.heightBox,
                      //ourButton(color: redColor,title: login,textColor: whiteColor,onPress: (){}).box.width(context.screenWidth-50).make(),
                    ],
                  ).box.roundedFull.rounded.padding(EdgeInsets.only(left: 10,right: 10)).make(),


                ],),
            ),),
        ],)


    );
    return WillPopScope(
      onWillPop:_onWillPop,
      child: bgWidget(

         padding: EdgeInsets.only(top: 240, left: 10, right: 10,),

          child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Center(
          child: Container(
          margin: EdgeInsets.only(top: 0,left: 10,right: 10,bottom: 140),

            child: SafeArea(

                child: Column(
                  children: [

                    Lottie.asset("assets/animations/newPin.json",width: 150,height: 150),
                    changePin(hint: newPinhint, controller: newpinController),
                    1.heightBox,
                    changePin(hint: reenterNewPinhint, controller: reenternewpinController),

                    ElevatedButton(
                      onPressed: () async {
                        String newPin = newpinController.text.trim();
                        String reenterPin = reenternewpinController.text.trim();

                        if (newPin.isEmpty || reenterPin.isEmpty) {
                          String msg = "कृपया आपला नवीन पिन टाका.";
                          if (newPin.isEmpty) {
                            SnackbarHelper.showSnackBar2(
                              context,
                              msg: msg,
                              height: 220.0,
                            );
                          } else if (reenterPin.isEmpty) {
                            msg = "कृपया आपला नवीन पिन पुन्हा टाका.";
                            SnackbarHelper.showSnackBar2(
                              context,
                              msg: msg,
                              height: 220.0,
                            );
                          }
                          return; // Exit onPressed function if any field is empty
                        }
                        if (newPin != reenterPin) {
                          String msg = "कृपया दोन्ही पिन सारखेच टाका.";
                          SnackbarHelper.showSnackBar2(
                            context,
                            msg: msg,
                            height: 220.0,
                          );
                          return; // Exit onPressed function if newPin and reenterPin do not match
                        }
                        String successMsg = "आपला पिन सफलतापूर्वक जतन केला गेला आहे.";
                        SnackbarHelper.showSnackbar(
                          context,
                          msg: successMsg,
                          height: 220.0,
                        );
                        performSetPin();
                        try {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (context) => BottomNav(),
                            ),
                          );
                        } catch (e, s) {
                          print(s);
                        }
                      },
                      child: Align(
                        child: SizedBox(
                          height: 50,
                          child: newPin.text.fontFamily(bold).size(22).make().paddingAll(10),
                        ),
                      ),
                    ),
                    10.heightBox,
                  ],
                ).box.height(380).border(color: Colors.black,width: 3).white.rounded.padding(EdgeInsets.only(top: 5,left: 10,right: 10)).make(),

              ),
            ),
        ),

      )),
    );



  }
  void setConfirm() {
    String confirmLoginPin = newpinController.text;
    if (confirmLoginPin.length == 4) {
      performSetPin();
    }
  }
  void moveConfirm() {
    String loginPin = reenternewpinController.text;
    if (loginPin.length == 4) {
      FocusScope.of(context).requestFocus(FocusNode());
      FocusScope.of(context).requestFocus(FocusNode());
    }
  }

  Future<void> performSetPin() async {
    //  String oldPin = await SharedPreferencesHelper.getLoginPin();
    // String oldLoginPin = oldpinController.text;
    String loginPin = newpinController.text;
    String confirmLoginPin = reenternewpinController.text;
    // print("oldLoginPin $oldLoginPin");
    print("loginPin $loginPin");
    print("confirmLoginPin $confirmLoginPin");
    if (loginPin.length == 4 && confirmLoginPin.length == 4 && loginPin == confirmLoginPin) {
      await SharedPreferencesHelper.setLoginPin(loginPin);
      String msg="आपला पिन सफलतापूर्वक बदलेला आहे";
      SnackbarHelper.showSnackbar(context,msg: msg,height: 220.0);

      //do after rohit call
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) =>AuthenticateController()));// Store PIN using SharedPreferencesHelper

      // Navigate to the next screen or perform any other actions
    } else {
      // String msg="Error: New PIN and Confirm PIN do not match";
      showToast('Error: New PIN and Confirm PIN do not match');
      // SnackbarHelper.showSnackBar2(context,msg: msg,height: 220.0);
    }
  }
  void showToast(String message) {
    // Implement a toast-like notification
    print(message);
  }
}

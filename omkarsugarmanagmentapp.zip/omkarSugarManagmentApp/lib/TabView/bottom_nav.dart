import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:omkarsugarmanagmentapp/TabView/tab_1.dart';
import 'package:omkarsugarmanagmentapp/TabView/tab_2.dart';
import 'package:omkarsugarmanagmentapp/TabView/tab_3.dart';
import 'package:omkarsugarmanagmentapp/TabView/tab_4.dart';

class BottomNav extends StatefulWidget {
  final int? index;
  final String? sugarFactoryId;
  const BottomNav({Key? key, this.index, this.sugarFactoryId}) : super(key: key);

  @override
  State<BottomNav> createState() => _BottomNavState();
}

class _BottomNavState extends State<BottomNav> with SingleTickerProviderStateMixin {
  late TabController controller;
  late List<Widget> tabBarViews;
  final tabIconSize = 40.0;


  // Add a state variable to hold the current tab index
  int _currentIndex = 0;
  static Color darkgreen = const Color(0xFF4CAF50);
  static const Color brownColor = Color(0xFFB08401);
  //static const Color darkRed = Color(0xFFF44236);
  //static const Color darkRed = Color(0xF5FF8080);
  static const Color darkRed = Color(0xCCFF8080);

  static const Color darkBlue = Color(0xFF008596);
  static const Color darkBlue1 = Color(0xFF2196F3);

  @override
  void initState() {
    super.initState();
    controller = TabController(vsync: this, length: 4);
    tabBarViews = [
      Tab1(sugarFactoryId: widget.sugarFactoryId),
      Tab2(sugarFactoryId: widget.sugarFactoryId),
      Tab3(sugarFactoryId: widget.sugarFactoryId),
      Tab4(sugarFactoryId: widget.sugarFactoryId)
    ];

    // Add listener to update state when the tab changes
    controller.addListener(() {
      setState(() {
        _currentIndex = controller.index;
      });
    });
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {

    double maxWidth = MediaQuery.of(context).size.height *2;

    return Scaffold(
      backgroundColor: Colors.white,

      bottomNavigationBar: Container(

        height: 80,


        child:  Material(


            color: _getCurrentTabColor(),


            child: ConstrainedBox(
              constraints: BoxConstraints(maxWidth: maxWidth),
              child: Wrap(
                  children: [
                    Column(
                      children: [
                        TabBar(

                          controller: controller,
                          tabs: [
                            Tab(

                              icon: Container(
                                width: 40, // Adjust the width as needed
                                height: 38,
                                // Adjust the height as needed
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(color: Colors.black, width: 2.0),
                                ),
                                child: Lottie.asset(
                                  'assets/animations/factoryanim.json',
                                  fit: BoxFit.fitHeight,
                                ),
                              ),
                              text: "ऊस गाळप",
                            ),
                            Tab(
                              icon: Container(
                                width: 40, // Adjust the width as needed
                                height: 38,
                                // Adjust the height as needed
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(color: Colors.black, width: 2.0),
                                ),
                                child: Lottie.asset(
                                  'assets/animations/factoryanim.json',
                                  fit: BoxFit.contain,
                                ),
                              ),
                              text: "चा.ऊस नोंद",
                            ),
                            Tab(
                              icon: Container(
                                width: 40, // Adjust the width as needed
                                height: 38,
                                // Adjust the height as needed
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(color: Colors.black, width: 2.0),
                                ),
                                child: Lottie.asset(
                                  'assets/animations/factoryanim.json',
                                  fit: BoxFit.contain,
                                ),
                              ),
                              text: "पु.ऊस नोंद",
                            ),
                            Tab(
                              icon: Container(
                                width: 40, // Adjust the width as needed
                                height: 38,
                                // Adjust the height as needed
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(color: Colors.black  , width: 2.0),
                                ),
                                child: Lottie.asset(
                                  'assets/animations/factoryanim.json',
                                  fit: BoxFit.contain,
                                ),
                              ),
                              text: "विक्री/साठा",
                            ),


                          ],
                          labelColor: Colors.white,
                          unselectedLabelColor: Colors.white,
                        ),
                      ],

                    ),
                  ]
              ),
            ),
          ),

      ),
      // Set background color based on the current tab

      // body: TabBarView(
      //   children: tabBarViews,
      //   controller: controller,
      //
      // ),

      body:Stack(
        children: [
          Positioned.fill(
            child: _getLottieAnimationForCurrentTab(),
          ),
          Container(
            // color: Colors.transparent,
            child: TabBarView(
              children: tabBarViews,
              controller: controller,
            ),
          ),
        ],
      )

      ,
    );
  }
  Widget _getLottieAnimationForCurrentTab() {
    switch (_currentIndex) {
      case 0:
        return Lottie.asset(
          "assets/animations/tab1cf.json",
          fit: BoxFit.cover,
        );
      case 1:
        return Lottie.asset(
          "assets/animations/tab2cf.json",
          fit: BoxFit.cover,
        );
      case 2:
        return Lottie.asset(
          "assets/animations/tab3cf.json",
          fit: BoxFit.cover,
        );
      case 3:
        return Lottie.asset(
          "assets/animations/tab4cf.json",
          fit: BoxFit.cover,
        );
      default:
        return Container(); // Return an empty container for safety
    }
  }
  // Define background colors for each tab
  Color _getCurrentTabColor() {
    List<Color> backgroundColors = [
      darkgreen,
      brownColor,
      darkBlue,
      darkRed,
    ];
    return backgroundColors[_currentIndex];
  }
}

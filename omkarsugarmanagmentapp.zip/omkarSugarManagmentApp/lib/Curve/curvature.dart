import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

class CustomAppBar extends StatefulWidget implements PreferredSizeWidget {
  final double preferredWidth;

  CustomAppBar({Key? key, this.preferredWidth = kToolbarHeight}) : super(key: key);

  @override
  Size get preferredSize => Size(preferredWidth, kToolbarHeight);

  @override
  _CustomAppBarState createState() => _CustomAppBarState();
}

class _CustomAppBarState extends State<CustomAppBar> {
  @override
  // Widget build(BuildContext context) {
  //
  //   return CustomPaint(
  //     painter: _AppBarPainter(),
  //     size: Size.fromHeight(widget.preferredWidth),
  //
  //       child: Container(
  //        //color: Colors.white,
  //         padding: EdgeInsets.only(left: 5),
  //         height: kToolbarHeight,
  //         alignment: Alignment.centerLeft,
  //         child: Transform.translate(
  //           offset: Offset(0, 130), // Adjust the offset to center the text
  //           child: Text(
  //             'ओंकार शुगर आणि \n डिस्टिलरी पावर प्रा.लि.',
  //             maxLines: 4, // Set max lines to 3
  //             overflow: TextOverflow.ellipsis,
  //
  //             style: TextStyle(
  //               color: Colors.white,
  //               fontSize: 20,
  //               fontStyle: FontStyle.values.first,
  //               fontWeight: FontWeight.bold,
  //               fontFamily: 'YourFontFamily',
  //             ),
  //           ),
  //         ),
  //       ),
  //
  //   );
  // }


  Widget build(BuildContext context) {
    return Stack(
      children: [
        CustomPaint(
          painter: _AppBarPainter(),
          size: Size.fromHeight(widget.preferredWidth),
            child: Container(
              //color: Colors.white,
              padding: EdgeInsets.only(left: 3),
              height: kToolbarHeight,
              alignment: Alignment.centerLeft,
              child: Stack(
                children: [
                  Transform.translate(
                    offset: Offset(0, 130), // Adjust the offset to center the text
                    child: Text(
                      'ओंकार शुगर आणि \n डिस्टिलरी पावर प्रा.लि.',
                      maxLines: 4, // Set max lines to 3
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 19,
                        fontStyle: FontStyle.values.first,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'YourFontFamily',
                      ),
                    ),

                  ),


                ],
              ),
            )

        ),



      ],
    );
  }
}

class _AppBarPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final Paint paint = Paint()..color = Colors.green;
    final double circleRadius = size.height / 3;
    final double halfCircleRadius = circleRadius / 10;
    final double offset = 0; // adjust the offset as needed

    // Draw right circle
    canvas.drawCircle(Offset(size.height+10 - circleRadius, size.width / 2), circleRadius+130, paint);

    // Draw left half circle
    canvas.drawArc(
      Rect.fromLTWH(0, 0, circleRadius * 2, circleRadius * 2),
      0,
      -0.4,
      true,
      paint,
    );

    // Draw left circle half part
    Path path = Path()
      ..moveTo(0, circleRadius)
      ..quadraticBezierTo(offset, circleRadius, offset, circleRadius + halfCircleRadius)
      ..quadraticBezierTo(offset, circleRadius + 2 * halfCircleRadius, 0, circleRadius + 2 * halfCircleRadius)
      ..close();

    canvas.drawPath(path, paint);


  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}



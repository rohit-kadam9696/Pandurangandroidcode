import 'dart:convert';
import 'dart:developer';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:omkarsugarmanagmentapp/GridView/sugargactory_gridview.dart';
import 'package:omkarsugarmanagmentapp/UI/change_pin_activity.dart';
import 'package:omkarsugarmanagmentapp/auth_screen/login_screen.dart';
import 'package:omkarsugarmanagmentapp/constant/snackbar_helper.dart';
import '../ApiResponse/api_response.dart';
import '../SharedPreference/shared_pref.dart';
import '../UI/otp_activity.dart';
import 'package:http/http.dart' as http;

class ApiServices {

  static Future<void> doLogin(String mobileno, String imei, String randomString, String versionId, String chitBoyId, String sugarFactoryId) async {
    if (mobileno.isNotEmpty) {
      String baseUrl = ApiResponse.determineBaseUrl(sugarFactoryId);
      print("baseurl os: ${baseUrl}");
      String uri = '$baseUrl/app_login';
      print("uri is: ${uri}");
      Map<String, dynamic> requestBody = {
        'action': "Login",
        'mobileno': mobileno,
        'imei': imei,
        'randomString': randomString,
        'versionId': versionId,
        'chitBoyId': chitBoyId,
        'sugarFactoryId': sugarFactoryId,
      };

      String json = jsonEncode(requestBody);
      try {
        var res = await http.post(
          Uri.parse(uri),
          body: json,
          headers: {'Content-Type': 'application/json'},
        );
        double customHeight = 220.0;
        if (res.statusCode == 200) {

          print("HOW ARE YOU");
          var jsondecode = jsonDecode(res.body);
          log("Login response: $jsondecode");
          if (jsondecode.containsKey("success") && jsondecode["success"] == true) {
            String chitBoyId = jsondecode["chitBoyId"];
            String randomString = jsondecode["uniquestring"];
            String mobileno = jsondecode["mobileno"];
            await SharedPreferencesHelper.storeValuesInSharedPref(chitBoyId, randomString, mobileno, imei, sugarFactoryId);
            SharedPreferencesHelper.updateSugarFactoryId(sugarFactoryId);
            String storedMobileNo = await SharedPreferencesHelper.getMobileNo();
            String oldPin = await SharedPreferencesHelper.getLoginPin();



            Get.to(() => OtpActivity(
              imei: imei,
              randomString: randomString,
              versionId: versionId,
              chitBoyId: chitBoyId,
              sugarFactoryId: sugarFactoryId,
            ));
            //Get.to(() => Page())
          } else {
            String servererrormsg = jsondecode['se']['msg'];
            Get.snackbar('Error', servererrormsg, snackPosition: SnackPosition.BOTTOM, duration: Duration(seconds: 3));
          }
        } else {
          print('Error: ${res.statusCode}');
        }
      } catch (e) {
        print('Error in HTTP request: $e');
      }
    } else {
      print("Please Fill All Details");
    }
  }
  static Future<void> fetchCorrectOtpFromServer(String mobileno, String otp, String? chitBoyId, String imei, String randomString, String versionId,String sugarFactoryId,BuildContext context) async {
    // ConstantFunction cf = ConstantFunction();
    if (mobileno.isNotEmpty) {
      try {
        // var connectivityResult = await Connectivity().checkConnectivity();
        String baseUrl =ApiResponse.determineBaseUrl(sugarFactoryId);
        String uri = '$baseUrl/app_login';
        Map<String, dynamic> requestBody = {
          'action': 'verifyotp',
          'mobileno': mobileno,
          'otp': otp,
          'chitBoyId': chitBoyId,
          'imei': imei,
          'randomString': randomString,
          'versionId': versionId,
          'sugarFactoryId':sugarFactoryId,
        };
        String json = jsonEncode(requestBody);
        var res = await http.post(
          Uri.parse(uri),
          body: json,
          headers: {'Content-Type': 'application/json'},
        );
        double customHeight = 220.0;
        if (res.statusCode == 200) {
          var jsondecode = jsonDecode(res.body);

          print("verify otp :${jsondecode} ");
          if (jsondecode.containsKey("success") && jsondecode["success"] == true) {
            String randomString = jsondecode['uniquestring'];
            String slipboycode = jsondecode['slipboycode'];
            String mobileno = jsondecode['mobileno'];
            String yearCode = jsondecode['harvestingYearCode'];
            SharedPreferencesHelper.storeValuesInSharedPref(slipboycode, randomString, mobileno, imei,sugarFactoryId);
            SharedPreferencesHelper.updateYearCode(yearCode);


            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (context) => ChangePinActivity(),
              ),
            );
          } else {
            String servererrormsg = jsondecode['se']['msg'];
            SnackbarHelper.showSnackbar(
              context,
              msg: servererrormsg,
              height: customHeight,
            );
          }
        } else {
          print('Error: ${res.statusCode}');
        }
      } catch (error) {
        print('Error: $error');
      }
    } else {
      print("Please Fill All Details");
    }
  }

  static Future<void> resendOtp(String mobileno, String chitBoyId, String imei, String randomString, String versionId,String sugarFactoryId,BuildContext context) async {

    if (mobileno.isNotEmpty) {
      try {

        String baseUrl =ApiResponse.determineBaseUrl(sugarFactoryId);
        String uri = '$baseUrl/app_login';
        Map<String, dynamic> requestBody = {
          'action': 'resendotp',
          'mobileno': mobileno,
          'chitBoyId': chitBoyId,
          'imei': imei,
          'randomString': randomString,
          'versionId': versionId,
          'sugarFactoryId':sugarFactoryId,
        };
        String json = jsonEncode(requestBody);
        var res = await http.post(
          Uri.parse(uri),
          body: json,
          headers: {'Content-Type': 'application/json'},
        );
        double customHeight = 220.0;
        if (res.statusCode == 200) {
          var jsondecode = jsonDecode(res.body);
          if (jsondecode.containsKey("success") && jsondecode["success"] == true) {
            String chitBoyId = jsondecode["slipboycode"];
            String randomString = jsondecode["uniquestring"];
            String mobileno = jsondecode['mobileno'];

            SharedPreferencesHelper.storeValuesInSharedPref(chitBoyId, randomString, mobileno, imei,sugarFactoryId);

            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (context) => OtpActivity(
                  imei: imei,
                  randomString: randomString,
                  versionId: versionId,
                  chitBoyId: chitBoyId,
                  sugarFactoryId:sugarFactoryId,
                ),
              ),
            );
          } else {
            String servererrormsg = jsondecode['se']['msg'];
            SnackbarHelper.showSnackbar(
              context,
              msg: servererrormsg,
              height: customHeight,
            );
          }
        } else {
          print('Error: ${res.statusCode}');
        }
      } catch (error) {
        print('Error: $error');
      }
    } else {
      print("Please Fill All Details");
    }
  }


}

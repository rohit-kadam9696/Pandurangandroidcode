import 'dart:developer';


import 'package:flutter/cupertino.dart';
import 'package:toastification/toastification.dart';

import '../consts/consts.dart';

void loginMobileNo(String mobileno,BuildContext context)
{

  }

